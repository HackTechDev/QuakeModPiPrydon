                                                                             
   ����    ��                             ����                               
 ����������  ���                        �� ����                              
 � �� � ������  �                       � ��                                 
 ���� � �     �� �                       �� �                                
      � �      � � ��� ���   ��    ���   ��� ����    �����    ���  ���       
      � �      � ���� ��� ������� ������� ��������  ���� ��  ��� ���� ���    
      � �      � �  � � ����  � �    � � �     � ����   �� ��  � �   �� �    
      � �      � �  � �  ��   � �    � � �     � �� �     � �  � �    � �    
      � �      � �  � �       � �    � � �     � �� �     � �  � �    � �    
      � ����������  � ����    �� ����� ���������������� �����  � ���  � �    
      � �������      ����       ������ �  ����       �����     ����    ����  
      � ��                           � �                                     
      ��  ����                 ����� ���                                     
        ������                 �������                                       
                                                                             
                           Prydon Gate Demo Version 1.3                      
                               �                                             
                             �������                                         
                           ��� ������                ��                      
                          ���                       ��                       
                          ��              ���     �� ����     ���            
                         � �  �������� ����� ��  ��� ����  ����� ��          
                         � � � ���� � ���   �� �   � �    � �   �� �         
                         � �������� �  ������� �   � �    � �������          
                          �  ��   � � � ���� � �   � �  ��� ���  ���         
                           �� ������  � ������ ��  ��������� ����� �         
                             �����     ����� ����    ����  ��������          
                                                                             
                                                                             

Released December 2nd, 2003


ATTENTION
---------

This demo should be considered BETA quality and not representative of the
final game. This demo is being released as an appeal to the Quake and gaming
community for help. If you'd like to help develop this game, please contact
the authors at frikac@inside3d.com.

This version REQUIRES Quake to run. The full game most likely will not. The
reason is we don't yet have enough original sounds and content.


About
-----

Prydon Gate is a hack and slash action adventure role playing game similar
in game play to some giants in the history of games such as Diablo. Prydon
Gate's game play may seem strikingly similar to that game, but it is not our
intention to make a Diablo or any other game port. Prydon Gate as you will
see, has quite a few unique twists that should keep the game interesting
and repayable numerous times.


The Story So Far
----------------

The young prince Ithael is banished by his father King Morgan to the hostile
territory of Lord Collwen in the frozen north. After meeting a friendly face,
the wizard Sadoc, Ithael spends the night in the local Inn to rest and
recuperate, for on the following day he has vowed to return to his homeland
and save the woman he loves from the tyranny of his father.

Prydon Gate is divided into 3 Acts each taking place in the ancient fantasy
realm of Prydon. This demo contains the first quest of the first act: After
Ithael awakens in the Inn and tries to journey out he discovers that during
the night the town has been locked down and all the villagers have taken
refuge within the decaying town walls. Under Capel Curig lurks something else
though, some evil brewing. With his trusty club given to him by Sadoc, Ithael
ventures into the sewers to banish the evil from whence it came.


What is in this Demo
--------------------

2 levels set in the frozen lands of Lord Collwen
42 basic items with 94 different affixes yielding thousands of combinations
8 spells
3 different monster types
Take on the dungeons with a friend - full coop support!


What isn't in the Demo
----------------------

Hundreds more unique and powerful items for you to find
Over 30 classes for your character
and much much more...


Installation
------------

Quake 1.08 or higher is required to play. If you're still playing with
Quake 1.01 or 1.06 you're living in the dark ages. Quake 1.08 is available
as free upgrade on ftp.idsoftware.com. The DOS Quake executables will not
work under Windows 2k or Windows XP. For these operating systems please
use Winquake, also available freely on the id software ftp.
Create a folder in your Quake folder called "Prydon" and copy all files
from this archive into it. To run the game, use the command line:

winquake -game Prydon

If your system has an OpenGL compatible 3d accelerator (pretty much stock
these days) you can use an enhanced version of Quake called GLQuake. This too
can be obtained from the idsoftware ftp. To run this, substitute
winquake with glquake in the above command line.

Also recommended is the engine DarkPlaces,which enables even more features.
This engine can be downloaded from:

http://icculus.org/twilight/darkplaces/


Playing on PC
-------------

To play Prydon Gate on the PC it is recommended you bind your left mouse
button using the customize controls menu under options to "Attack". This
can also be done with the following command entered into the console:

bind mouse1 "+attack"

It is recommended also to have your right  mouse button bound to "Jump",
again to do this from the console:

bind mouse2 "+jump"

This will allow you to cast spells with the right mouse button and pickup,
use and attack with the left. In addition you should bind the following keys
(this part must be done from the game console)

bind h "heal"
bind m "mana"
bind space "mainmenu"

"heal" causes you to use a heal potion from your inventory
"mana" causes you to use a mana potion from your inventory
"mainmenu" will open the main menu !!VERY IMPORTANT!!


Playing on the Dreamcast
------------------------

Prydon Gate was made with the original Titanium Studios port of Quake to the
Dreamcast in mind, and should play well with any upcoming ports.

To help you use Prydon Gate with QuakeDC, a sample configuration is provided
in prydon.cfg located inside the pak file. Simply uncomment the configuration,
repak it into pak0.pak, rename and burn as usual.

Prydon Gate also has a (less advanced) joystick capable console made
especially with Dreamcast users in mind. In addition, Prydon Gate's Inn
saves are possibly the smallest of any Quake mod.


Playing over the Internet
-------------------------

While internet play is certainly not recommended, you can set temp1 1 in the
server console to disable some effects that may contribute to lag. The level
must be reloaded for this to have any effect.

Saving Your Game
----------------

It should be noted that unlike Quake you cannot simply save your game
anywhere you choose, you must use the Inn from each town to save your
progress. In multiplayer, you will only be able to save your character if the
server supports file access.
Turning off Music
-----------------

Some Quake purists may not like the music in Prydon Gate, so you can switch it
off by setting temp1 2 in the console and reloading the map.


Enhanced Engines
----------------

Prydon Gate supports certain "enhanced engine features", it checks for them
with "checkextension", a feature developed by LordHavoc. Below is a list of
enhanced engine features Prydon Gate uses:

DP_TE_PARTICLESNOW
  Only supported by DarkPlaces that we're aware of. This accelerates and
  improves snow effects in the north regions. (Download from the DP homepage:
  http://icculus.org/twilight/darkplaces/)

TQ_SNOW
  Supported by TomazQuake (http://tomaz.quakesrc.org) and most engines based
  on TomazQuake (CheapHack, Telejano, etc). Also to be supported in an
  upcoming version of NGLQuake (http://ssj4death.condemned.com). This feature
  accelerates and improves snow effects in the north regions of the game.
  
QSG_FILE
  This extension represents my original file access tutorial on QuakeSRC.org.
  Although supported, it is recommended to switch to FRIK_FILE. This feature
  allows a character to be saved to a file for multiplayer game saving.

FRIK_FILE
  This extension is my original file access tutorial from QuakeSRC.org with
  corrected builtin numbers. The builtin numbers are taken from the Maddes
  version of the tutorial.
  
EBFS
  Not an extension but another version checking system, Prydon Gate supports
  EBFS (Extended Built in Function System) for locating and using the QSG_FILE
  commands mentioned above. This feature allows cooperative characters to
  be saved in a multi player game.
  
DP_ENT_ALPHA
  Supported by TomazQuake and DarkPlaces, this feature allows the roofs of
  buildings in towns and in the wilderness to fade away when your player
  enters. Purely a visual enhancement.

DP_SV_DRAWONLYTOCLIENT
  Supported by TomazQuake and DarkPlaces and perhaps others, Prydon Gate will
  use this feature if present to lighten lag and make the cursor sprites
  invisible to other players in multiplayer.
  

Thanks and Credits
------------------

Thanks to Blizzard Entertainment for Diablo, Diablo II and Warcraft II
If you do not own all three of the above, you must buy them immediately. :)

Thank you to Nihilistic Software for Vampire: The Masquerade: Redemption. A
fine game.

Raven games for Hexen II and Heretic II. Two more must-owns.

A great big thank you to Gas Powered Games for Dungeon Siege. Many elements in
this game are inspired by that game.

Big thanks to the team behind Fantasy Quake: Rise of the Pheonix, especially
their modelers: Shaper and Arjuna.

Thanks by association to Team Evolve for the DarkMare project. (Whatever
happened to this?)

Thanks to the BloodMage team, especially my long lost friend MaNiAc and their
modeler 'Curse'.

Thanks to the makers of After The Fall Quake TC. Fine mod.

Makers of the Tribes 'RPG mod'. (?)

Whoever made these skins I'm using. I lost track of the authors, I've reused
them so often. You know who you are, it doesn't matter that I don't.


Credits
-------

Contains original artwork by: Brambo, Random Man, FrikaC, Akuma, Renegade
(Ugly, hideous) Maps by Frika C
(Beautiful, wonderful) Code by Frika C
Original Concept by Renegade
Story and Design by FrikaC
Play testing by Quest and Gleeb


Help and Troubleshooting
------------------------

If you need help please post on http://forums.inside3d.com or send a mail to
frikac@inside3d.com. Be sure to put "Prydon Gate" in the topic. I will not
respond 'good job' or 'you suck' mails, As these do not demand a reply.
Replies may be delayed or may not come at all, depending on the content of
the message. If you want fast help, use the above stated forum.

Bug reports are appreciated, if possible make a save game at the point the
bug occurred in game, and provide a method for reproducing the bug. Credit
will be given.


Future
------

If you'd like to help with Prydon Gate and are a competent mapper (meaning you
can make maps better than seen in this demo). I urge you to help. A full
development kit will be made available soon that will allow creating whole
new episodes (new quests, npcs, shops, whatever) with Prydon Gate. Please
check back at the site regularly.

If you can model for Quake, we need your help. The majority of models in this
game are either substandard or we're not satisfied with the license under
which we obtained them (*cough*). If you can improve upon or merely substitute
just about any model in the game, we'd appreciate it.

If you have an 'interesting voice' and would like to play a role of one of the
characters in the mod, great! Send us a sample of your voice via e-mail and
we can probably find a character for you. But if we don't find enough people
willing to do voices, don't be surprised if we don't get back to you.

If you can create sound effects or know of some royalty free sounds which we
can use, we need your help! Many sounds of this mod need to be replaced to
become a stand alone game.


Copyright and Distribution
--------------------------

All original material shouldn't be stolen and reused, but it will be so 
I don't care anyway. You can mirror this file, modify this file or use this
file as a head rest, but you may not claim this file or portions of it as your
own, that just irks me. If you're thinking about doing something with this file
outside of what you're supposed to do, stop thinking about it and go get a
drink and maybe watch some TV. Your whole life shouldn't be doing illegal
things with this file. Get out, live a little, it will do you some good. In
fact, stop reading this readme, it's a big waste of your time. Everything
we own belongs to us and usually nobody else. That's what ownership is really
all about. As such, we own it and we're just letting you use and distribute it.
That's the basics right there. It's like if I handed you a watch, and said you
could use it for the day. This doesn't suddenly become your watch, you can't go
brag to your friend "hey look at my new watch!", that'd be wrong. So just don't
do that with this file. Sure, if you want to make a mod and use some files we 
made that are in this file we'll let you, but don't just redress the mod and
rerelease it, that's like putting some red paint on the watch and claiming
it's an entirely different watch. The persons portrayed in this demo don't
actually exist and we have no proof they ever existed so any resemblance to
persons living or undead is purely coincidental. Locations in this demo
actually do exist, but they're not as cute as we make them seem. They are
horrid horrid places as most of them are in Britain. Not that I have anything
against Britain, but they're just... you know. Some of my best friends are from
Britain in fact so don't start accusing me of hating Britain. Oh, King Morgan
is an actual historical figure so scratch that last thing about never existing.
Chances are he won't sue us though since he died over a 1000 years ago. 

(C) Copyright 2002-2003. All rights reserved.
 
 
Availability
------------

Prydon Gate is available from the following location:

http://www.inside3d.com/prydongate/
